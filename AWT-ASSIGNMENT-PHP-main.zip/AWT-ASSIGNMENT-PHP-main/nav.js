function createACC() {
  location.href = "./createACC.html";
}
function Data_E() {
  location.href = "./Data_Entry_.php";
}
function Data_R() {
  location.href = "./Data_Retrieval_.php";
}
function Go_home() {
  location.href = "./home.php";
}
function Go_login() {
  location.href = "./login.html";
}
